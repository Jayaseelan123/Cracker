@extends('layouts.app')

@section('title', 'home')

@section('hero_title', 'Welcome to CrackerTime')
@section('hero_subtitle', 'Shop the best festive crackers')

@section('content')
    <!-- CATEGORIES EXPLORER (Image Style) -->
    @if(\App\Models\SiteSetting::bool('enable_category_filter', true))
    <div class="category-explorer-section mb-5">
        <div class="section-title-wrapper text-center mb-4">
            <h2 class="section-title">Explore Categories</h2>
            <div class="title-underline"></div>
        </div>

        <!-- CATEGORY SEARCH BAR -->
        <div class="search-filter-container container mb-4" style="max-width: 500px;">
            <div class="input-group shadow-sm rounded-pill overflow-hidden border" style="background:#fff;">
                <span class="input-group-text bg-white border-0 ps-3">
                    <i class="fas fa-search text-muted"></i>
                </span>
                <input type="text" id="categorySearchInput" class="form-control border-0 py-2 ps-2" placeholder="Search categories..." style="outline: none; box-shadow: none;">
                <button class="btn border-0 bg-white pe-3" type="button" id="clearCategorySearchBtn" style="display: none;">
                    <i class="fas fa-times text-muted"></i>
                </button>
            </div>
        </div>
        <div id="noCategoriesMsg" class="text-center text-muted mb-4" style="display: none;">
            <h5 class="mb-0">No Categories Found</h5>
        </div>
        
        <div class="category-carousel-container">
            <button class="carousel-nav-btn prev" id="catPrev"><i class="fas fa-chevron-left"></i></button>
            <div class="category-grid carousel-scroll" id="catCarousel">
                @foreach($categories as $category)
                @php 
                    $catImg  = $category->image ? asset('category_images/' . $category->image) : asset('images/image.png');
                    $catSlug = $category->slug ?? Str::slug($category->name);
                @endphp
                <a href="{{ route('front.products') }}#cat-{{ $catSlug }}" class="category-card">
                    <div class="category-img-container">
                        <img src="{{ $catImg }}" alt="{{ $category->name }}">
                    </div>
                    <div class="category-card-name">{{ $category->name }}</div>
                </a>
                @endforeach
            </div>
            <button class="carousel-nav-btn next" id="catNext"><i class="fas fa-chevron-right"></i></button>
        </div>
    </div>
    @endif

    <!-- Shop CTA Banner -->
    <!-- <div class="text-center py-5 my-4" style="background: linear-gradient(135deg, #0d6b8a 0%, #1a8ab0 100%); border-radius: 20px; box-shadow: 0 10px 40px rgba(13,107,138,0.2);">
        <i class="fas fa-fire fa-3x mb-3" style="color:#ff9900;"></i>
        <h3 class="fw-bold text-white mb-2">Explore Our Full Product Range</h3>
        <p class="text-white mb-4" style="opacity:0.85;">Browse all categories, search by name or code, and add directly to your cart.</p>
        <a href="{{ route('front.products') }}" class="btn btn-lg rounded-pill px-5 fw-bold" style="background: linear-gradient(135deg,#ff9900,#ff3b3b); color:#fff; box-shadow: 0 4px 20px rgba(255,153,0,0.4); font-size:1.1rem;">
            <i class="fas fa-shopping-bag me-2"></i> View All Products
        </a>
    </div> -->

    <!-- ============================================================
         SECTION 1 : SHOP BY OCCASION
    ============================================================ -->
    <div class="py-5 my-5">
        <div class="section-title-wrapper text-center mb-5">
            <h2 class="section-title">Shop by Occasion</h2>
            <div class="title-underline mx-auto"></div>
            <p class="text-muted mt-3">Find the perfect crackers for every celebration</p>
        </div>
        <div class="row g-4">
            @php
            $occasions = [
                ['icon'=>'fa-star',        'color'=>'#ff9900', 'bg'=>'rgba(255,153,0,0.1)',   'title'=>'Diwali',          'desc'=>'Light up the festival of lights with our premium Diwali special cracker combos.'],
                ['icon'=>'fa-birthday-cake','color'=>'#e91e63', 'bg'=>'rgba(233,30,99,0.1)',   'title'=>'Birthdays',       'desc'=>'Make every birthday blast-worthy with our safe and colourful birthday specials.'],
                ['icon'=>'fa-ring',        'color'=>'#9c27b0', 'bg'=>'rgba(156,39,176,0.1)',   'title'=>'Weddings',        'desc'=>'Grand wedding celebrations deserve the grandest fireworks. Shop our wedding packages.'],
                ['icon'=>'fa-flag',        'color'=>'#1a8ab0', 'bg'=>'rgba(26,138,176,0.1)',   'title'=>'National Holidays','desc'=>'Celebrate Independence Day, Republic Day & more with patriotic sparkle sets.'],
                ['icon'=>'fa-pray',        'color'=>'#4caf50', 'bg'=>'rgba(76,175,80,0.1)',    'title'=>'Puja & Festivals', 'desc'=>'Auspicious moments deserve auspicious crackers — explore our puja festival range.'],
                ['icon'=>'fa-trophy',      'color'=>'#ff5722', 'bg'=>'rgba(255,87,34,0.1)',    'title'=>'Achievements',    'desc'=>'Top of the class, big promotion, or sports victory — celebrate wins with a bang!'],
            ];
            @endphp
            @foreach($occasions as $occ)
            <div class="col-6 col-md-4 col-lg-2">
                <a href="{{ route('front.products') }}" class="text-decoration-none">
                    <div class="text-center p-4 rounded-4 h-100 occasion-card" style="background:{{ $occ['bg'] }}; border:2px solid {{ $occ['color'] }}22; transition:transform 0.3s,box-shadow 0.3s;">
                        <div class="mb-3" style="width:64px;height:64px;background:{{ $occ['bg'] }};border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto;border:2px solid {{ $occ['color'] }}44;">
                            <i class="fas {{ $occ['icon'] }} fa-2x" style="color:{{ $occ['color'] }};"></i>
                        </div>
                        <h6 class="fw-bold mb-1" style="color:#1a2233;">{{ $occ['title'] }}</h6>
                        <p class="text-muted mb-0" style="font-size:0.78rem;line-height:1.4;">{{ $occ['desc'] }}</p>
                    </div>
                </a>
            </div>
            @endforeach
        </div>
    </div>

    <!-- ============================================================
         SECTION 2 : HOW IT WORKS
    ============================================================ -->
    <div class="py-5 my-3" style="background:linear-gradient(135deg,#f8fafc 0%,#e8f4f8 100%);border-radius:24px;">
        <div class="section-title-wrapper text-center mb-5">
            <h2 class="section-title">How It Works</h2>
            <div class="title-underline mx-auto"></div>
            <p class="text-muted mt-3">Order your favourite crackers in just 4 simple steps</p>
        </div>
        <div class="row g-4 px-3 justify-content-center">
            @php
            $steps = [
                ['step'=>'01','icon'=>'fa-search',        'color'=>'#0d6b8a','title'=>'Browse & Search',    'desc'=>'Explore 200+ products across all categories. Use our smart search to find by name or code in seconds.'],
                ['step'=>'02','icon'=>'fa-cart-plus',     'color'=>'#ff9900','title'=>'Add to Cart',         'desc'=>'Select your quantities directly on the product page. Your cart updates instantly without any page reload.'],
                ['step'=>'03','icon'=>'fa-map-marker-alt','color'=>'#e91e63','title'=>'Enter Delivery Info', 'desc'=>'Fill in your delivery address and choose your nearest delivery zone for accurate charges.'],
                ['step'=>'04','icon'=>'fa-check-circle',  'color'=>'#4caf50','title'=>'Order Confirmed!',    'desc'=>'Receive instant confirmation. We pack and dispatch your order safely, right to your doorstep.'],
            ];
            @endphp
            @foreach($steps as $i => $step)
            <div class="col-12 col-md-6 col-lg-3">
                <div class="d-flex flex-column align-items-center text-center position-relative p-4">
                    <!-- Connector line (desktop only) -->
                    @if($i < 3)
                    <div class="d-none d-lg-block position-absolute" style="top:40px;right:-30px;width:60px;height:3px;background:linear-gradient(90deg,{{ $step['color'] }},{{ $steps[$i+1]['color'] }});border-radius:2px;z-index:1;"></div>
                    @endif
                    <div style="width:80px;height:80px;border-radius:50%;background:{{ $step['color'] }};display:flex;align-items:center;justify-content:center;box-shadow:0 8px 25px {{ $step['color'] }}44;margin-bottom:16px;position:relative;z-index:2;">
                        <i class="fas {{ $step['icon'] }} fa-2x text-white"></i>
                        <span style="position:absolute;top:-8px;right:-8px;background:#fff;color:{{ $step['color'] }};font-size:0.7rem;font-weight:900;width:26px;height:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;border:2px solid {{ $step['color'] }};box-shadow:0 2px 8px rgba(0,0,0,0.1);">{{ $step['step'] }}</span>
                    </div>
                    <h6 class="fw-bold mb-2" style="color:#1a2233;font-size:1rem;">{{ $step['title'] }}</h6>
                    <p class="text-muted mb-0" style="font-size:0.85rem;line-height:1.6;">{{ $step['desc'] }}</p>
                </div>
            </div>
            @endforeach
        </div>
    </div>

    <!-- ============================================================
         SECTION 3 : WHY FAMILIES CHOOSE US
    ============================================================ -->
    <div class="py-5 my-5">
        <div class="section-title-wrapper text-center mb-5">
            <h2 class="section-title">Why Families Choose Us</h2>
            <div class="title-underline mx-auto"></div>
            <p class="text-muted mt-3">Year after year, thousands of families trust us for their celebrations</p>
        </div>
        <div class="row g-4">
            @php
            $reasons = [
                ['icon'=>'fa-shield-alt',  'color'=>'#0d6b8a','title'=>'100% Licensed & Safe',         'desc'=>'Every product we sell is government approved and manufactured under strict safety guidelines. Your family\'s safety is our priority.'],
                ['icon'=>'fa-tags',        'color'=>'#ff9900','title'=>'Best Price Guarantee',          'desc'=>'We work directly with factories to offer you wholesale prices. No middlemen, no markup — just the best deals in town.'],
                ['icon'=>'fa-truck',       'color'=>'#4caf50','title'=>'Fast Home Delivery',            'desc'=>'Order by 6 PM and we\'ll dispatch your crackers the very next morning. Pan-India delivery with real-time updates.'],
                ['icon'=>'fa-box-open',    'color'=>'#e91e63','title'=>'Bulk & Gift Packs',             'desc'=>'Planning for the whole colony? Our special bulk packs and beautifully wrapped gift sets make group celebrations easy.'],
                ['icon'=>'fa-headset',     'color'=>'#9c27b0','title'=>'24/7 Customer Support',         'desc'=>'Our dedicated support team is available round the clock via WhatsApp, phone, and email — before, during, and after your order.'],
                ['icon'=>'fa-recycle',     'color'=>'#00bcd4','title'=>'Eco-Friendly Options',          'desc'=>'We stock a wide range of low-smoke, green crackers certified by PESO. Celebrate responsibly without compromising on fun.'],
                ['icon'=>'fa-lock',        'color'=>'#ff5722','title'=>'Secure Payments',               'desc'=>'Your payment information is always protected. We support multiple payment modes including UPI, net banking, and COD.'],
                ['icon'=>'fa-heart',       'color'=>'#f44336','title'=>'Trusted by 10,000+ Families',  'desc'=>'From small towns to big cities, over 10,000 families have made us their go-to cracker shop — and keep coming back every year.'],
            ];
            @endphp
            @foreach($reasons as $r)
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="p-4 rounded-4 h-100 why-card" style="background:#fff;border:1px solid #e8f0f5;transition:all 0.3s ease;box-shadow:0 2px 15px rgba(0,0,0,0.05);">
                    <div style="width:54px;height:54px;background:{{ $r['color'] }}18;border-radius:14px;display:flex;align-items:center;justify-content:center;margin-bottom:16px;">
                        <i class="fas {{ $r['icon'] }}" style="font-size:1.4rem;color:{{ $r['color'] }};"></i>
                    </div>
                    <h6 class="fw-bold mb-2" style="color:#1a2233;font-size:0.95rem;">{{ $r['title'] }}</h6>
                    <p class="text-muted mb-0" style="font-size:0.82rem;line-height:1.6;">{{ $r['desc'] }}</p>
                </div>
            </div>
            @endforeach
        </div>
    </div>

    <!-- ============================================================
         SECTION 4 : CLIENT REVIEWS CAROUSEL
    ============================================================ -->
    <div class="py-5 my-3" style="background:linear-gradient(135deg,#0d6b8a 0%,#1a3a5c 100%);border-radius:24px;overflow:hidden;">
        <div class="section-title-wrapper text-center mb-5">
            <h2 style="font-size:2.2rem;font-weight:900;color:#fff;margin-bottom:5px;text-transform:uppercase;letter-spacing:1px;">What Our Customers Say</h2>
            <div class="title-underline mx-auto"></div>
            <p class="mt-3" style="color:rgba(255,255,255,0.75);">Real experiences from real families across India</p>
        </div>

        @php
        $reviews = [
            ['name'=>'Priya Sharma',   'city'=>'Chennai',    'stars'=>5, 'avatar'=>'PS', 'color'=>'#ff9900', 'text'=>'Ordered for Diwali and the delivery was super fast! The crackers were high quality and the kids had an absolute blast. Will definitely order again next year!'],
            ['name'=>'Rajesh Kumar',   'city'=>'Coimbatore', 'stars'=>5, 'avatar'=>'RK', 'color'=>'#e91e63', 'text'=>"Best prices I've found anywhere online. The bulk pack was great value and came neatly packed. Customer support answered my query within minutes via WhatsApp."],
            ['name'=>'Anitha Devi',    'city'=>'Madurai',    'stars'=>5, 'avatar'=>'AD', 'color'=>'#4caf50', 'text'=>"Used them for my daughter's wedding. The sparklers and flower pots were absolutely gorgeous! Guests were amazed. Highly recommend their wedding special combo."],
            ['name'=>'Suresh Babu',    'city'=>'Salem',      'stars'=>4, 'avatar'=>'SB', 'color'=>'#9c27b0', 'text'=>'Good variety of eco-friendly crackers. Happy that they stock green alternatives. Delivery was on time and packing was very secure. Solid 4 stars!'],
            ['name'=>'Kavitha R.',     'city'=>'Trichy',     'stars'=>5, 'avatar'=>'KR', 'color'=>'#00bcd4', 'text'=>"Third year ordering from them and they never disappoint. The website is so easy to use now — found exactly what I needed in minutes and checkout was smooth."],
            ['name'=>'Muthu Krishnan', 'city'=>'Sivakasi',   'stars'=>5, 'avatar'=>'MK', 'color'=>'#ff5722', 'text'=>"As someone from Sivakasi, I know my crackers! These guys source quality products and prices are very fair. The gift packs are beautifully presented too."],
        ];
        // Split into slides of 3 for desktop
        $slides = array_chunk($reviews, 3);
        @endphp

        <!-- Carousel -->
        <div id="reviewsCarousel" class="carousel slide px-3 px-md-4" data-bs-ride="carousel" data-bs-interval="4000">

            <!-- Indicators / Dots -->
            <div class="carousel-indicators" style="bottom:-10px;">
                @foreach($slides as $idx => $slide)
                    <button type="button" data-bs-target="#reviewsCarousel" data-bs-slide-to="{{ $idx }}"
                        class="{{ $idx === 0 ? 'active' : '' }}"
                        style="width:10px;height:10px;border-radius:50%;background:{{ $idx === 0 ? '#ffcc00' : 'rgba(255,255,255,0.4)' }};border:none;margin:0 5px;">
                    </button>
                @endforeach
            </div>

            <!-- Slides -->
            <div class="carousel-inner pb-5">
                @foreach($slides as $idx => $slide)
                <div class="carousel-item {{ $idx === 0 ? 'active' : '' }}">
                    <div class="row g-4">
                        @foreach($slide as $rev)
                        <div class="col-12 col-md-4">
                            <div class="p-4 rounded-4 h-100"
                                 style="background:rgba(255,255,255,0.09);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,0.18);min-height:240px;">
                                <!-- Stars -->
                                <div class="mb-3">
                                    @for($s = 1; $s <= 5; $s++)
                                        <i class="fas fa-star" style="color:{{ $s <= $rev['stars'] ? '#ffcc00' : 'rgba(255,255,255,0.2)' }};font-size:0.88rem;"></i>
                                    @endfor
                                </div>
                                <!-- Review Text -->
                                <p style="color:rgba(255,255,255,0.88);font-size:0.88rem;line-height:1.7;margin-bottom:20px;">"{{ $rev['text'] }}"</p>
                                <!-- Reviewer -->
                                <div class="d-flex align-items-center gap-3 mt-auto">
                                    <div style="width:44px;height:44px;border-radius:50%;background:{{ $rev['color'] }};display:flex;align-items:center;justify-content:center;font-weight:900;color:#fff;font-size:0.82rem;flex-shrink:0;">{{ $rev['avatar'] }}</div>
                                    <div>
                                        <div style="color:#fff;font-weight:700;font-size:0.88rem;">{{ $rev['name'] }}</div>
                                        <div style="color:rgba(255,255,255,0.5);font-size:0.75rem;"><i class="fas fa-map-marker-alt me-1"></i>{{ $rev['city'] }}, Tamil Nadu</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endforeach
            </div>

            <!-- Prev / Next Arrows -->
            <button class="carousel-control-prev" type="button" data-bs-target="#reviewsCarousel" data-bs-slide="prev"
                    style="width:44px;height:44px;background:rgba(255,255,255,0.15);border-radius:50%;top:50%;transform:translateY(-50%);left:6px;border:1px solid rgba(255,255,255,0.25);">
                <i class="fas fa-chevron-left" style="color:#fff;font-size:14px;"></i>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#reviewsCarousel" data-bs-slide="next"
                    style="width:44px;height:44px;background:rgba(255,255,255,0.15);border-radius:50%;top:50%;transform:translateY(-50%);right:6px;border:1px solid rgba(255,255,255,0.25);">
                <i class="fas fa-chevron-right" style="color:#fff;font-size:14px;"></i>
                <span class="visually-hidden">Next</span>
            </button>
        </div>

        <!-- Summary Stats -->
        <div class="row g-4 px-3 mt-5 text-center">
            <div class="col-4">
                <div style="color:#ffcc00;font-size:2.5rem;font-weight:900;line-height:1;">10K+</div>
                <div style="color:rgba(255,255,255,0.7);font-size:0.85rem;">Happy Customers</div>
            </div>
            <div class="col-4">
                <div style="color:#ffcc00;font-size:2.5rem;font-weight:900;line-height:1;">4.9★</div>
                <div style="color:rgba(255,255,255,0.7);font-size:0.85rem;">Average Rating</div>
            </div>
            <div class="col-4">
                <div style="color:#ffcc00;font-size:2.5rem;font-weight:900;line-height:1;">8yr</div>
                <div style="color:rgba(255,255,255,0.7);font-size:0.85rem;">In Business</div>
            </div>
        </div>
    </div>

    <div class="text-center py-5 my-4" style="background: linear-gradient(135deg, #0d6b8a 0%, #1a8ab0 100%); border-radius: 20px; box-shadow: 0 10px 40px rgba(13,107,138,0.2);">
        <i class="fas fa-fire fa-3x mb-3" style="color:#ff9900;"></i>
        <h3 class="fw-bold text-white mb-2">Explore Our Full Product Range</h3>
        <p class="text-white mb-4" style="opacity:0.85;">Browse all categories, search by name or code, and add directly to your cart.</p>
        <a href="{{ route('front.products') }}" class="btn btn-lg rounded-pill px-5 fw-bold" style="background: linear-gradient(135deg,#ff9900,#ff3b3b); color:#fff; box-shadow: 0 4px 20px rgba(255,153,0,0.4); font-size:1.1rem;">
            <i class="fas fa-shopping-bag me-2"></i> View All Products
        </a>
    </div>





    

    @push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Category Search Logic
            const catSearchInput = document.getElementById('categorySearchInput');
            const catClearBtn = document.getElementById('clearCategorySearchBtn');
            const catCards = document.querySelectorAll('.category-card');
            const catNoMsg = document.getElementById('noCategoriesMsg');

            if (catSearchInput && catCards.length > 0) {
                catSearchInput.addEventListener('keyup', function() {
                    const term = this.value.toLowerCase().trim();
                    let hasVisible = false;

                    catClearBtn.style.display = term.length > 0 ? 'block' : 'none';

                    catCards.forEach(card => {
                        const name = card.querySelector('.category-card-name').textContent.toLowerCase();
                        if (name.includes(term)) {
                            card.style.display = 'block';
                            hasVisible = true;
                        } else {
                            card.style.display = 'none';
                        }
                    });

                    if (catNoMsg) {
                        catNoMsg.style.display = hasVisible ? 'none' : 'block';
                    }
                });

                if (catClearBtn) {
                    catClearBtn.addEventListener('click', function() {
                        catSearchInput.value = '';
                        catSearchInput.dispatchEvent(new Event('keyup'));
                        catSearchInput.focus();
                    });
                }
            }
        });
    </script>
    @endpush
@endsection
