<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Str;

class CategoryController extends Controller
{
    public function index(Request $request)
    {
        $categories = Category::when($request->search, function ($query) use ($request) {
            $query->where('name', 'LIKE', "%{$request->search}%")
                ->orWhere('tamil_name', 'LIKE', "%{$request->search}%");
        })
        ->orderBy('id', 'desc')
        ->paginate(10);

        return view('admin.category.index', compact('categories'));
    }

    public function create()
    {
        return view('admin.category.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255|unique:categories,name',
            'tamil_name' => 'nullable|string|max:255',
            'slug' => 'nullable|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048'
        ]);

        $slugSource = $request->input('slug') ?: $request->input('name');
        $base = Str::slug($slugSource);
        $slug = $base;
        $counter = 1;
        while (Category::where('slug', $slug)->exists()) {
            $slug = $base . '-' . $counter;
            $counter++;
        }

        $imageName = null;
        if ($request->hasFile('image')) {
            $imageName = time() . '.' . $request->image->extension();
            $request->image->move(public_path('category_images'), $imageName);
        }

        Category::create([
            'name' => $request->name,
            'tamil_name' => $request->tamil_name,
            'slug' => $slug,
            'image' => $imageName
        ]);

        return redirect()->route('category.index')->with('success', 'Category Added Successfully!');
    }

    public function edit(Category $category)
    {
        return view('admin.category.edit', compact('category'));
    }

    public function update(Request $request, Category $category)
    {
        $request->validate([
            'name' => 'required|string|max:255|unique:categories,name,' . $category->id,
            'tamil_name' => 'nullable|string|max:255',
            'slug' => 'nullable|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048'
        ]);

        $slugSource = $request->input('slug') ?: $request->input('name');
        $base = Str::slug($slugSource);
        $slug = $base;
        $counter = 1;
        while (Category::where('slug', $slug)->where('id', '!=', $category->id)->exists()) {
            $slug = $base . '-' . $counter;
            $counter++;
        }

        $imageName = $category->image;
        if ($request->hasFile('image')) {
            if ($category->image && file_exists(public_path('category_images/' . $category->image))) {
                unlink(public_path('category_images/' . $category->image));
            }
            $imageName = time() . '.' . $request->image->extension();
            $request->image->move(public_path('category_images'), $imageName);
        }

        $category->update([
            'name' => $request->name,
            'tamil_name' => $request->tamil_name,
            'slug' => $slug,
            'image' => $imageName
        ]);

        return redirect()->route('category.index')->with('success', 'Category Updated Successfully!');
    }

    public function destroy(Category $category)
    {
        if ($category->image && file_exists(public_path('category_images/' . $category->image))) {
            unlink(public_path('category_images/' . $category->image));
        }
        $category->delete();
        return back()->with('success', 'Category Deleted!');
    }
}
