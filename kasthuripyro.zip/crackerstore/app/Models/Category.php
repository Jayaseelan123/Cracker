<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'tamil_name',
        'slug',
        'image',
    ];

    /**
     * Get products for the category.
     */
    public function products()
    {
        return $this->hasMany(Product::class);
    }
}
