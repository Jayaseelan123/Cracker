<?php if($paginator->hasPages()): ?>
<div class="d-flex justify-content-between align-items-center mt-3 px-1" style="background:#f8f9fa; border-top:1px solid #e9ecef; border-radius:0 0 6px 6px; padding:10px 16px;">

    
    <div class="text-muted" style="font-size:13.5px;">
        Showing <strong><?php echo e($paginator->firstItem()); ?></strong>
        to <strong><?php echo e($paginator->lastItem()); ?></strong>
        of <strong><?php echo e($paginator->total()); ?></strong> results
    </div>

    
    <ul class="pagination mb-0" style="gap:3px;">

        
        <?php if($paginator->onFirstPage()): ?>
            <li class="page-item disabled">
                <span class="page-link" style="border-radius:4px; font-size:13px; padding:5px 10px; border-color:#dee2e6; color:#adb5bd;">&lsaquo;</span>
            </li>
        <?php else: ?>
            <li class="page-item">
                <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" style="border-radius:4px; font-size:13px; padding:5px 10px; border-color:#dee2e6; color:#495057;">&lsaquo;</a>
            </li>
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_string($element)): ?>
                <li class="page-item disabled">
                    <span class="page-link" style="border-radius:4px; font-size:13px; padding:5px 10px; border-color:#dee2e6;"><?php echo e($element); ?></span>
                </li>
            <?php endif; ?>

            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <li class="page-item active">
                            <span class="page-link" style="border-radius:4px; font-size:13px; padding:5px 11px; background:#0d6efd; border-color:#0d6efd; color:#fff; font-weight:600;"><?php echo e($page); ?></span>
                        </li>
                    <?php else: ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($url); ?>" style="border-radius:4px; font-size:13px; padding:5px 11px; border-color:#dee2e6; color:#495057;"><?php echo e($page); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <li class="page-item">
                <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" style="border-radius:4px; font-size:13px; padding:5px 10px; border-color:#dee2e6; color:#495057;">&rsaquo;</a>
            </li>
        <?php else: ?>
            <li class="page-item disabled">
                <span class="page-link" style="border-radius:4px; font-size:13px; padding:5px 10px; border-color:#dee2e6; color:#adb5bd;">&rsaquo;</span>
            </li>
        <?php endif; ?>

    </ul>
</div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\crackerstone\crackerstore\resources\views/vendor/pagination/bootstrap-5.blade.php ENDPATH**/ ?>