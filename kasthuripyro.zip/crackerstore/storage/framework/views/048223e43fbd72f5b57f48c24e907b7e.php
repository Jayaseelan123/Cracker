<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Products List</title>
    <style>
        <?php
            $fontSize = \App\Models\SiteSetting::get('pdf_font_size', '9');
            $showDiscount = \App\Models\SiteSetting::bool('show_discount_row', true);
            $showCode = \App\Models\SiteSetting::bool('show_product_code', false);
            $priceFormat = \App\Models\SiteSetting::get('price_format', '&#8377;');
        ?>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            margin: 0;
            padding: 20px;
            color: #333;
            font-size: <?php echo e($fontSize); ?>pt;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #0a4f68;
            padding-bottom: 10px;
        }
        .header h1 {
            margin: 0;
            color: #0a4f68;
        }
        .header p {
            margin: 5px 0 0;
            color: #666;
            font-size: 14px;
        }
        .category-header {
            background-color: #0a4f68;
            color: #fff;
            padding: 8px 15px;
            font-size: 18px;
            font-weight: bold;
            margin-top: 20px;
            margin-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .text-right {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="header">
        <?php if(\App\Models\SiteSetting::bool('print_show_logo', true) && $company && $company->logo): ?>
            <img src="<?php echo e(public_path($company->logo)); ?>" alt="Logo" style="max-height: 50px; margin-bottom: 10px;">
        <?php endif; ?>
        <h1><?php echo e($company->company_name ?? 'Kasthuripyro'); ?></h1>
        <p>Products Price List - <?php echo e(date('F d, Y')); ?></p>
        <?php if($company && $company->contact_number): ?>
            <p>Phone: <?php echo e($company->contact_number); ?> 
                <?php if($company->whatsapp_number): ?> | WhatsApp: <?php echo e($company->whatsapp_number); ?> <?php endif; ?>
            </p>
        <?php endif; ?>
    </div>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($category->products->count() > 0): ?>
            <div class="category-header">
                <?php echo e($category->name); ?>

            </div>
            <table>
                <thead>
                    <tr>
                        <th width="15%" class="text-center">Product ID</th>
                        <th width="<?php echo e($showDiscount ? '35%' : '60%'); ?>">Product Name</th>
                        <?php if($showDiscount): ?>
                        <th width="25%" class="text-center">MRP (<?php echo $priceFormat; ?>)</th>
                        <?php endif; ?>
                        <th width="25%" class="text-center">Price (<?php echo $priceFormat; ?>)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center" style="font-weight:700; color:#0a4f68; font-size:0.88em; letter-spacing:0.5px;">
                                <?php echo e($product->product_id ?? ('CKR-' . str_pad($product->id, 4, '0', STR_PAD_LEFT))); ?>

                            </td>
                            <td>
                                <?php if($showCode && !empty($product->sku)): ?>
                                    <span style="font-size: 0.9em; color: #555;">[<?php echo e($product->sku); ?>]</span> 
                                <?php endif; ?>
                                <?php echo e($product->name_en ?? $product->name); ?>


                            </td>
                            <?php if($showDiscount): ?>
                            <td class="text-center"><?php echo e(number_format($product->mrp, 2)); ?></td>
                            <?php endif; ?>
                            <td class="text-center"><strong><?php echo e(number_format($product->price, 2)); ?></strong></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($customMsg = \App\Models\SiteSetting::get('print_custom_message')): ?>
        <div style="margin-top: 30px; text-align: center; font-size: 0.9em; color: #555; border-top: 1px solid #ddd; padding-top: 10px;">
            <?php echo nl2br(e($customMsg)); ?>

        </div>
    <?php endif; ?>

</body>
</html>
<?php /**PATH C:\wamp64\www\crackerstone\crackerstore\resources\views/front/products-pdf.blade.php ENDPATH**/ ?>