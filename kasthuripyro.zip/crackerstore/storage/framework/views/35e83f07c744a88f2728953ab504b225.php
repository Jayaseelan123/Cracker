<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('hero_title', 'Our Products'); ?>
<?php $__env->startSection('hero_subtitle', 'Browse our wide range of premium crackers'); ?>

<?php $__env->startSection('content'); ?>

    <!-- PRODUCTS SECTION START -->
    <?php if(\App\Models\SiteSetting::bool('show_pricelist_home', true)): ?>
    <div id="products-list" class="text-center mb-5 mt-5" style="scroll-margin-top: 80px;">
        <h2 class="section-title">All Products</h2>
        <div class="title-underline"></div>
        <p class="text-muted mt-2">Browse our wide range of premium crackers</p>
    </div>

    <div class="search-filter-container container mb-5" style="max-width: 620px;">
        <div class="input-group shadow rounded-pill overflow-hidden" style="background:#fff; border: 2px solid #0a4f68; transition: box-shadow 0.3s;" id="productSearchBox">
            <span class="input-group-text bg-white border-0 ps-3" style="font-size:1.1rem;">
                <i class="fas fa-search" style="color:#0a4f68;"></i>
            </span>
            <input type="text" id="productSearchInput" class="form-control border-0 py-3 ps-2"
                placeholder="Search products by name or code..."
                style="outline: none; box-shadow: none; font-size: 1rem;"
                autocomplete="off">
            <button class="btn border-0 bg-white pe-3" type="button" id="clearSearchBtn" style="display: none; color:#0a4f68;">
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="category-header" id="cat-<?php echo e($category->slug ?? Str::slug($category->name)); ?>">
            <i class="fas fa-fire"></i>
            <?php echo e($category->name); ?>

        </div>

        <div class="table-responsive">
            <table class="table product-table">
                <thead>
                    <tr>
                        <th style="text-align:center; white-space:nowrap;font-size:20px;">Product&nbsp;ID</th>
                        <th style="text-align:left; white-space:nowrap;font-size:20px;">Image</th>
                        <th style="text-align:left; white-space:nowrap;font-size:20px;">Product</th>
                        <?php if(\App\Models\SiteSetting::bool('show_discount_row', true)): ?>
                        <th style="text-align:center; white-space:nowrap;font-size:20px;">MRP</th>
                        <?php endif; ?>
                        <th style="text-align:center; white-space:nowrap;font-size:20px;">Price</th>
                        <th style="text-align:center; white-space:nowrap;font-size:20px;">Quantity</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $productImg   = asset('product_images/' . ($product->image_path ?: $product->image ?: 'demo.jpg'));
                            $vid = '';
                            if (($product->video_status ?? 'Active') === 'Active') {
                                // Prioritize local MP4 file upload over YouTube URL
                                if (!empty($product->video)) {
                                    $vid = asset('product_videos/' . $product->video);
                                } elseif (!empty($product->video_url)) {
                                    $vid = $product->video_url;
                                }
                            }
                            $productVideo = $vid;
                            $productName  = addslashes($product->name_en ?? $product->name ?? '');
                            $productTa    = addslashes($product->name_ta ?? '');
                            $productMrp   = number_format($product->mrp, 2);
                            $productPrice = number_format($product->price, 2);
                        ?>
                        <tr class="product-row">
                            <td style="text-align:center; font-weight:600; font-size: 20px; color:#0a4f68; white-space:nowrap; vertical-align:middle; letter-spacing:0.5px;">
                                <?php echo e($product->product_id ?? 'CKR-' . str_pad($product->id, 4, '0', STR_PAD_LEFT)); ?>

                            </td>
                            <td style="text-align:left;">
                                <?php if($vid): ?>
                                    <div style="position:relative;display:inline-block;cursor:pointer;" onclick="openPreviewModal('<?php echo e($productName); ?>', '<?php echo e($productImg); ?>', '<?php echo e($productVideo); ?>')">
                                        <img src="<?php echo e($productImg); ?>" alt="<?php echo e($product->name_en ?? $product->name); ?>" style="border-radius:6px;max-width:80px;">
                                        <span style="position:absolute;bottom:3px;right:3px;background:rgba(0,0,0,0.6);border-radius:50%;width:22px;height:22px;display:flex;align-items:center;justify-content:center;">
                                            <i class="fas fa-play" style="color:#fff;font-size:9px;margin-left:2px;"></i>
                                        </span>
                                    </div>
                                <?php else: ?>
                                    <img src="<?php echo e($productImg); ?>" alt="<?php echo e($product->name_en ?? $product->name); ?>" style="cursor:pointer;border-radius:6px;max-width:80px;" onclick="openPreviewModal('<?php echo e($productName); ?>', '<?php echo e($productImg); ?>', '')">
                                <?php endif; ?>
                            </td>
                            <td style="text-align:left;">
                                <?php if(\App\Models\SiteSetting::bool('show_product_code', false) && !empty($product->sku)): ?>
                                    <div class="text-primary small fw-bold mb-1">Code: <?php echo e($product->sku); ?></div>
                                <?php endif; ?>
                                <div style="font-size:1.2rem; font-weight:600; line-height:1.4;"><?php echo e($product->name_en ?? $product->name ?? '—'); ?></div>

                                <?php if($vid): ?>
                                    <div class="mt-1"><span class="badge" style="background:#0a4f68;font-size:10px;"><i class="fas fa-video me-1"></i>Has Video</span></div>
                                <?php endif; ?>
                            </td>
                            <?php if(\App\Models\SiteSetting::bool('show_discount_row', true)): ?>
                            <td style="text-align:center; font-weight: bold; font-size: 1.25em; color: #333;">&#8377; <?php echo e(number_format($product->mrp, 2)); ?></td>
                            <?php endif; ?>
                            <td style="text-align:center; font-weight: bold; font-size: 1.25em; color: #333;">&#8377; <?php echo e(number_format($product->price, 2)); ?></td>
                            <?php $cartItems = session('cart', []);
                            $cartQty = $cartItems[$product->id] ?? 0; ?>
                            <td style="text-align:center;">
                                <?php if($product->stock > 0): ?>
                                    <div class="qty-controls" style="justify-content:center;">
                                        <button type="button" data-id="<?php echo e($product->id); ?>"
                                            class="qty-btn minus qty-minus-btn">-</button>
                                        <input type="text" readonly class="qty-input qty-display-<?php echo e($product->id); ?>"
                                            value="<?php echo e($cartQty); ?>">
                                        <button type="button" data-id="<?php echo e($product->id); ?>" class="qty-btn plus qty-plus-btn">+</button>
                                    </div>
                                <?php else: ?>
                                    <div class="text-danger fw-bold">Out of Stock</div>
                                    <div class="qty-controls" style="justify-content:center; opacity: 0.5; pointer-events: none;">
                                        <button type="button" class="qty-btn minus" disabled>-</button>
                                        <input type="text" readonly class="qty-input" value="0">
                                        <button type="button" class="qty-btn plus" disabled>+</button>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">No products in this category.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {

            // ---- Scroll to category anchor on page load (from home category click) ----
            if (window.location.hash) {
                const targetId = window.location.hash.substring(1); // e.g. "cat-fireworks"
                const targetEl = document.getElementById(targetId);
                if (targetEl) {
                    // Slight delay so the page fully renders before scrolling
                    setTimeout(function () {
                        const offset = 85; // Fixed header height + buffer
                        const top = targetEl.getBoundingClientRect().top + window.pageYOffset - offset;
                        window.scrollTo({ top: top, behavior: 'smooth' });
                        // Highlight the category header briefly
                        targetEl.style.transition = 'box-shadow 0.4s ease';
                        targetEl.style.boxShadow = '0 0 0 4px rgba(255,153,0,0.6)';
                        setTimeout(() => { targetEl.style.boxShadow = ''; }, 2000);
                    }, 300);
                }
            }

            // ---- Search Box Focus Glow ----
            const searchBox = document.getElementById('productSearchBox');
            const searchInputEl = document.getElementById('productSearchInput');
            if (searchInputEl && searchBox) {
                searchInputEl.addEventListener('focus', function () {
                    searchBox.style.boxShadow = '0 0 0 4px rgba(10,79,104,0.18)';
                    searchBox.style.borderColor = '#0a4f68';
                });
                searchInputEl.addEventListener('blur', function () {
                    searchBox.style.boxShadow = '0 2px 8px rgba(0,0,0,0.08)';
                    searchBox.style.borderColor = '#0a4f68';
                });
            }

            // ---- Product Search Filter ----
            const searchInput  = document.getElementById('productSearchInput');
            const clearBtn     = document.getElementById('clearSearchBtn');
            const allRows      = document.querySelectorAll('tr.product-row');
            const categoryBlocks = document.querySelectorAll('.category-section-wrap');

            // Create "no results" message
            const noResultsMsg = document.createElement('div');
            noResultsMsg.id = 'noProductsMsg';
            noResultsMsg.className = 'text-center text-muted py-5';
            noResultsMsg.innerHTML = '<i class="fas fa-box-open fa-3x mb-3 d-block" style="color:#ccc;"></i><h5>No products found</h5><p>Try a different search term.</p>';
            noResultsMsg.style.display = 'none';
            const productsListDiv = document.getElementById('products-list');
            if (productsListDiv) productsListDiv.after(noResultsMsg);

            if (searchInput) {
                searchInput.addEventListener('input', function () {
                    const term = this.value.toLowerCase().trim();

                    // Toggle clear button
                    clearBtn.style.display = term.length > 0 ? 'block' : 'none';

                    let visibleTotal = 0;

                    // Loop through every table — show/hide rows
                    document.querySelectorAll('table.product-table').forEach(function (table) {
                        const rows   = table.querySelectorAll('tr.product-row');
                        let visCount = 0;

                        rows.forEach(function (row) {
                            // Search in: product name, product ID, SKU/code cells
                            const text = row.innerText.toLowerCase();
                            if (term === '' || text.includes(term)) {
                                row.style.display = '';
                                visCount++;
                            } else {
                                row.style.display = 'none';
                            }
                        });

                        visibleTotal += visCount;

                        // Show/hide the whole category block (header + table)
                        const catHeader = table.closest('.table-responsive') ? table.closest('.table-responsive').previousElementSibling : null;
                        const tableWrap = table.closest('.table-responsive');

                        if (visCount === 0 && term !== '') {
                            if (catHeader) catHeader.style.display = 'none';
                            if (tableWrap) tableWrap.style.display = 'none';
                        } else {
                            if (catHeader) catHeader.style.display = '';
                            if (tableWrap) tableWrap.style.display = '';
                        }
                    });

                    // Global no-results message
                    noResultsMsg.style.display = (visibleTotal === 0 && term !== '') ? 'block' : 'none';
                });

                // Clear button
                if (clearBtn) {
                    clearBtn.addEventListener('click', function () {
                        searchInput.value = '';
                        searchInput.dispatchEvent(new Event('input'));
                        searchInput.focus();
                    });
                }
            }
        });

        // Product Preview Modal using SweetAlert2
        function openPreviewModal(name, imageSrc, videoSrc) {
            let hasVideo = (videoSrc && videoSrc.trim() !== '');
            
            // Container with horizontal scroll
            let htmlContent = `
            <style>
                /* Custom scrollbar for preview */
                .preview-scroll-container::-webkit-scrollbar {
                    height: 6px;
                }
                .preview-scroll-container::-webkit-scrollbar-track {
                    background: #f1f1f1;
                    border-radius: 10px;
                }
                .preview-scroll-container::-webkit-scrollbar-thumb {
                    background: #0a4f68;
                    border-radius: 10px;
                }
                .preview-item {
                    min-width: 100%;
                    flex: 0 0 100%;
                    scroll-snap-align: center;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
            </style>`;
            
            if (hasVideo) {
                htmlContent += `<div style="font-size: 13px; color: #666; margin-bottom: 10px; animation: pulse 2s infinite;">
                                    <i class="fas fa-arrows-alt-h me-1"></i> Swipe or scroll horizontally to see video
                                </div>`;
            }

            htmlContent += `<div class="preview-scroll-container" style="display: flex; overflow-x: auto; overflow-y: hidden; scroll-snap-type: x mandatory; gap: 10px; padding-bottom: 15px; align-items: center; -webkit-overflow-scrolling: touch;">`;
            
            // Always show the image first
            htmlContent += `<div class="preview-item">
                                <img src="${imageSrc}" style="width:100%; max-height:60vh; border-radius:8px; object-fit:contain; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                            </div>`;
            
            // If there's a video, show it horizontally next to the image
            if (hasVideo) {
                // Determine if it's a YouTube URL or a direct video file
                if (videoSrc.includes('youtube.com') || videoSrc.includes('youtu.be')) {
                    // Extract video ID and use embed URL
                    let videoId = '';
                    if (videoSrc.includes('youtu.be/')) {
                        videoId = videoSrc.split('youtu.be/')[1].split('?')[0];
                    } else if (videoSrc.includes('v=')) {
                        videoId = videoSrc.split('v=')[1].split('&')[0];
                    } else if (videoSrc.includes('/embed/')) {
                        videoId = videoSrc.split('/embed/')[1].split('?')[0];
                    } else if (videoSrc.includes('/shorts/')) {
                        videoId = videoSrc.split('/shorts/')[1].split('?')[0];
                    }
                    
                    if (videoId) {
                        htmlContent += `<div class="preview-item">
                                            <div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:8px;width:100%; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                                                <iframe src="https://www.youtube.com/embed/${videoId}?autoplay=0" style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                                            </div>
                                        </div>`;
                    }
                } else if (videoSrc.endsWith('.mp4') || videoSrc.endsWith('.webm') || videoSrc.endsWith('.ogg') || videoSrc.includes('product_videos/')) {
                    htmlContent += `<div class="preview-item">
                                        <video width="100%" controls style="border-radius:8px; max-height:60vh; aspect-ratio: 16/9; background: #000; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                                            <source src="${videoSrc}" type="video/mp4">
                                            Your browser does not support the video tag.
                                        </video>
                                    </div>`;
                } else {
                    // For generic video links, try iframe
                    htmlContent += `<div class="preview-item">
                                        <div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:8px;width:100%; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                                            <iframe src="${videoSrc}" style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                                        </div>
                                    </div>`;
                }
            }
            
            htmlContent += `</div>`;

            Swal.fire({
                title: `<h4 style="margin:0;font-weight:600;color:#0a4f68;font-size:clamp(1rem, 4vw, 1.25rem);">${name}</h4>`,
                html: htmlContent,
                showCloseButton: true,
                showConfirmButton: false,
                width: '600px',
                padding: '1.5em',
            });
        }
    </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\crackerstone\crackerstore\resources\views/front/products.blade.php ENDPATH**/ ?>